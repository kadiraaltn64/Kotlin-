# WiFi Lab
Android/Kotlin Wi-Fi analiz ve güvenli simülasyon uygulaması.

Gerçek ağları tarar; SSID, BSSID, sinyal, frekans ve güvenlik bilgisini gösterir.
Simülasyon modu yalnızca uygulama içinde örnek ağlar gösterir; gerçek Wi-Fi kimliği taklit etmez.
