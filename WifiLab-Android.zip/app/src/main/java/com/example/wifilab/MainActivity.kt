package com.example.wifilab

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.wifi.WifiManager
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat

class MainActivity : AppCompatActivity() {
    private lateinit var wifi: WifiManager
    private lateinit var list: TextView
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        wifi = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        list = findViewById(R.id.list)
        status = findViewById(R.id.status)
        findViewById<Button>(R.id.scanButton).setOnClickListener { scan() }
        findViewById<Button>(R.id.simButton).setOnClickListener { simulation() }
        ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 10)
    }

    private fun scan() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 10)
            return
        }
        wifi.startScan()
        val results = wifi.scanResults.sortedByDescending { it.level }
        status.text = "Bulunan ağ: ${results.size}"
        list.text = results.joinToString("\n\n") {
            "SSID: ${it.SSID.ifBlank { "<gizli>" }}\nBSSID: ${it.BSSID}\nSinyal: ${it.level} dBm\nFrekans: ${it.frequency} MHz\nGüvenlik: ${it.capabilities}"
        }
    }

    private fun simulation() {
        status.text = "Güvenli simülasyon — gerçek yayın yapılmıyor."
        list.text = "TestNet-Open  | Açık ağ\nTestNet-WPA2  | WPA2\nTestNet-WPA3  | WPA3\nTestNet-Hidden | Gizli SSID\n\nBu mod yalnızca örnek ağları gösterir; gerçek bir erişim noktası oluşturmaz."
    }
}
